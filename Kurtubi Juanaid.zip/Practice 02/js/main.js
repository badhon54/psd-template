$('document').ready(function () {
	// Typed JS
	var typed = new Typed('.typed', {
		strings: ['Kurtubi Juanaid'],
		typeSpeed: 70,
		startDelay: 300,
		// loop: true,
		showCursor: false,
		// smartBackspace: true,
		// fadeOutClass: 'typed-fade-out',
	});
});